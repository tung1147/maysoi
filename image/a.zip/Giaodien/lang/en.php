<?php

/*
------------------
Language: English
------------------
*/
 
$lang = array();
 $lang['Danhmuc'] ='Menu';
$lang['sanphammoi']='New Products';
$lang['giavang']='Gold';
$lang['quangcao'] = 'Advertising';
$lang['dangnhap'] = 'Login';
$lang['giohang']='Cart';
$lang['hotrotructuyen']='Online Support';
$lang['thoitiet']='Weather';
$lang['sanpham']='Products';

?>