<?php
/*
------------------
Language: English
------------------
*/
 
$lang = array();
$lang['Danhmuc'] ='Danh m&#7909;c';
$lang['sanphammoi']='S&#7843;n ph&#7849;m m&#7899;i';
$lang['giavang']='Gi&#225; v&#224;ng';
$lang['quangcao'] = 'Qu&#7843;ng c&#225;o';
$lang['dangnhap'] = '&#272;&#259;ng nh&#7853;p';
$lang['giohang']='Gi&#7887; h&#224;ng';
$lang['hotrotructuyen']='H&#7895; tr&#7907; tr&#7921;c tuy&#7871;n';
$lang['thoitiet']='Th&#7901;i ti&#7871;t';
$lang['sanpham']='S&#7843;n ph&#7849;m';
?>